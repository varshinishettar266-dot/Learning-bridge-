import React, { useEffect, useMemo, useState } from 'react';
import { BookOpen, GraduationCap, LayoutDashboard, Wifi, WifiOff, Languages, Volume2, RefreshCw, CheckCircle2, ArrowLeft, Sparkles, BarChart3, LogOut } from 'lucide-react';
import { lessons } from './data';
import { getAllProgress, saveProgress } from './db';
import { firebaseReady, firestore } from './firebase';
import { doc, setDoc } from 'firebase/firestore';

const API = import.meta.env.VITE_API_URL || 'http://localhost:5000';
const text = (en, kn, language) => language === 'kn' ? kn : en;

export default function App() {
  const [page, setPage] = useState('home');
  const [student, setStudent] = useState(() => JSON.parse(localStorage.getItem('novaStudent') || 'null'));
  const [name, setName] = useState('');
  const [grade, setGrade] = useState('6');
  const [language, setLanguage] = useState('en');
  const [online, setOnline] = useState(navigator.onLine);
  const [records, setRecords] = useState([]);
  const [activeLesson, setActiveLesson] = useState(null);
  const [questionIndex, setQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState([]);
  const [finished, setFinished] = useState(false);
  const [message, setMessage] = useState('');

  useEffect(() => {
    const update = () => setOnline(navigator.onLine);
    window.addEventListener('online', update); window.addEventListener('offline', update);
    refresh();
    return () => { window.removeEventListener('online', update); window.removeEventListener('offline', update); };
  }, []);
  async function refresh() { try { const local = await getAllProgress(); let combined = local; if (navigator.onLine) { try { const response = await fetch(`${API}/api/progress`); if (response.ok) { const remote = await response.json(); const byId = new Map([...remote, ...local].map(r => [r.id, r])); combined = [...byId.values()]; } } catch { /* Local progress remains available if the server is unreachable. */ } } setRecords(combined); } catch (e) { console.error(e); } }
  function login(e) {
    e.preventDefault();
    if (!name.trim()) return;
    const profile = { name: name.trim(), grade, language };
    localStorage.setItem('novaStudent', JSON.stringify(profile)); setStudent(profile); setLanguage(profile.language); setPage('home');
  }
  function logout() { localStorage.removeItem('novaStudent'); setStudent(null); setPage('home'); }
  function startLesson(lesson) { setActiveLesson(lesson); setQuestionIndex(0); setAnswers([]); setFinished(false); setPage('lesson'); }
  function chooseAnswer(index) {
    const next = [...answers]; next[questionIndex] = index; setAnswers(next);
  }
  async function finishQuiz() {
    const correct = answers.reduce((sum, answer, i) => sum + (answer === activeLesson.questions[i].answer ? 1 : 0), 0);
    const total = activeLesson.questions.length;
    const score = Math.round(correct / total * 100);
    const wrongTopics = activeLesson.questions.filter((q, i) => answers[i] !== q.answer).map(q => q.topic);
    const record = {
      id: `${student.name.toLowerCase().replace(/\s+/g,'-')}-${activeLesson.id}-${Date.now()}`,
      studentName: student.name, grade: student.grade, language: student.language,
      lessonId: activeLesson.id, lessonTitle: activeLesson.title, score, correct, total,
      weakTopics: [...new Set(wrongTopics)], completedAt: new Date().toISOString(), synced: false
    };
    try { await saveProgress(record); await refresh(); } catch (e) { console.error(e); }
    setFinished(true);
  }
  async function syncProgress() {
    if (!online) { setMessage('You are offline. Connect to the internet to sync.'); return; }
    try {
      const local = await getAllProgress();
      if (!local.length) { setMessage('No quiz progress to sync yet.'); return; }
      const response = await fetch(`${API}/api/sync`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ records: local }) });
      if (!response.ok) throw new Error('Server could not save progress');
      if (firebaseReady) {
        for (const record of local) await setDoc(doc(firestore, 'studentProgress', record.id), record);
      }
      setRecords(local.map(r => ({ ...r, synced: true })));
      setMessage(firebaseReady ? 'Progress synced to server and Firestore!' : 'Progress synced to the server successfully!');
    } catch (e) { setMessage('Sync failed. Make sure the backend is running. ' + e.message); }
  }
  const myRecords = useMemo(() => records.filter(r => student && r.studentName === student.name), [records, student]);
  const average = myRecords.length ? Math.round(myRecords.reduce((s,r)=>s+r.score,0)/myRecords.length) : 0;

  if (!student) return <main className="login-screen"><section className="login-card"><div className="brand-mark"><GraduationCap size={34}/></div><p className="eyebrow">LEARN WITHOUT LIMITS</p><h1>Welcome to <span>NovaLearn</span></h1><p className="muted">Your learning journey can continue, even without internet.</p><form onSubmit={login} className="login-form"><label>Your name<input value={name} onChange={e=>setName(e.target.value)} placeholder="Enter your name" required /></label><label>Class<select value={grade} onChange={e=>setGrade(e.target.value)}><option value="6">Class 6</option><option value="7">Class 7</option><option value="8">Class 8</option></select></label><label>Learning language<select value={language} onChange={e=>setLanguage(e.target.value)}><option value="en">English</option><option value="kn">ಕನ್ನಡ (Kannada)</option></select></label><button className="primary full">Start learning <span>→</span></button></form><p className="tiny">Demo profile only · No password required</p></section></main>;

  return <div className="app-shell">
    <aside className="sidebar"><div className="brand"><div className="brand-mark small"><GraduationCap/></div><div><b>NovaLearn</b><small>LEARN ANYWHERE</small></div></div>
      <div className="nav-label">MENU</div>
      <button className={page==='home'?'nav active':'nav'} onClick={()=>setPage('home')}><BookOpen size={18}/> Student learning</button>
      <button className={page==='teacher'?'nav active':'nav'} onClick={()=>{setPage('teacher');refresh();}}><LayoutDashboard size={18}/> Teacher dashboard</button>
      <div className="sidebar-bottom"><div className="connection"><span className={online?'dot':'dot offline'}></span>{online?'Online':'Offline mode'}</div><div className="profile-mini"><div className="avatar">{student.name[0].toUpperCase()}</div><div><b>{student.name}</b><small>Class {student.grade}</small></div><button title="Log out" className="icon-btn" onClick={logout}><LogOut size={16}/></button></div></div>
    </aside>
    <main className="main-area"><header className="topbar"><div><p className="eyebrow">YOUR LEARNING SPACE</p><h2>{page==='teacher'?'Teacher dashboard':page==='lesson'?'Learning time':`Hello, ${student.name.split(' ')[0]}!`}</h2></div><div className="top-actions"><span className={online?'status':'status off'}>{online?<Wifi size={15}/>:<WifiOff size={15}/>} {online?'Online':'Offline'}</span><button className="language-btn" onClick={()=>setLanguage(language==='en'?'kn':'en')}><Languages size={17}/>{language==='en'?'English':'ಕನ್ನಡ'}</button></div></header>
      {message && <div className="notice" onClick={()=>setMessage('')}>{message} <b>×</b></div>}
      {page==='home' && <><section className="hero"><div><span className="hero-tag"><Sparkles size={14}/> PERSONALIZED LEARNING</span><h1>Small steps today.<br/><em>Big dreams tomorrow.</em></h1><p>Learn at your own pace, in your language, online or offline.</p><button className="hero-button" onClick={()=>startLesson(lessons[0])}>Continue learning <span>→</span></button></div><div className="hero-art"><div className="sun"></div><div className="book-illustration"><BookOpen size={76}/></div><div className="floating-note">✦ Keep growing!</div></div></section>
        <section className="stats-grid"><Stat label="Lessons available" value={lessons.length} note="Ready to explore" icon={<BookOpen/>}/><Stat label="Quizzes completed" value={myRecords.length} note="Your practice history" icon={<CheckCircle2/>}/><Stat label="Average score" value={`${average}%`} note="Across completed quizzes" icon={<BarChart3/>}/></section>
        <div className="section-heading"><div><p className="eyebrow">PICK UP WHERE YOU LEFT OFF</p><h3>Explore lessons</h3></div><span className="muted small-text">Available offline after first load</span></div>
        <div className="lesson-grid">{lessons.map((lesson,i)=><article className="lesson-card" key={lesson.id}><div className={`lesson-icon tone-${i}`}><BookOpen size={23}/></div><div className="lesson-meta"><span>{lesson.subject}</span><span>{lesson.minutes} min</span></div><h3>{text(lesson.title,lesson.titleKn,language)}</h3><p>{text(lesson.body,lesson.bodyKn,language).slice(0,105)}...</p><div className="lesson-footer"><span>{lesson.className}</span><button onClick={()=>startLesson(lesson)}>Open lesson <span>→</span></button></div></article>)}</div>
        <section className="sync-strip"><div className="sync-icon"><RefreshCw/></div><div><b>Keep your learning in sync</b><p>Your work is saved on this device. Sync when you are connected.</p></div><button className="secondary" onClick={syncProgress}>Sync progress</button></section>
      </>}
      {page==='lesson' && activeLesson && <section className="lesson-view"><button className="back-btn" onClick={()=>setPage('home')}><ArrowLeft size={16}/> Back to lessons</button>{!finished?<><div className="lesson-content"><span className="pill">{activeLesson.subject} · {activeLesson.className}</span><h1>{text(activeLesson.title,activeLesson.titleKn,language)}</h1><p className="lesson-copy">{text(activeLesson.body,activeLesson.bodyKn,language)}</p><button className="read-btn" onClick={()=>{const utterance=new SpeechSynthesisUtterance(text(activeLesson.body,activeLesson.bodyKn,language));utterance.lang=language==='kn'?'kn-IN':'en-IN';speechSynthesis.speak(utterance);}}><Volume2 size={17}/> Listen to lesson</button></div><div className="quiz-panel"><div className="quiz-top"><div><span className="eyebrow">QUICK PRACTICE</span><h2>Test your understanding</h2></div><span className="question-count">{questionIndex+1} / {activeLesson.questions.length}</span></div><div className="progress-track"><div style={{width:`${(questionIndex+1)/activeLesson.questions.length*100}%`}}/></div><h3>{text(activeLesson.questions[questionIndex].q,activeLesson.questions[questionIndex].qKn,language)}</h3><div className="answers">{activeLesson.questions[questionIndex].options.map((option,i)=><button key={option} className={answers[questionIndex]===i?'answer selected':'answer'} onClick={()=>chooseAnswer(i)}><span className="answer-letter">{String.fromCharCode(65+i)}</span>{option}</button>)}</div><div className="quiz-actions"><span className="muted small-text">Choose one answer</span><button className="primary" disabled={answers[questionIndex]===undefined} onClick={()=>questionIndex===activeLesson.questions.length-1?finishQuiz():setQuestionIndex(questionIndex+1)}>{questionIndex===activeLesson.questions.length-1?'Finish quiz':'Next question'} →</button></div></div></>:<div className="result-card"><div className="result-check"><CheckCircle2 size={38}/></div><p className="eyebrow">QUIZ COMPLETED</p><h1>Well done, {student.name.split(' ')[0]}!</h1><div className="score">{Math.round(answers.reduce((s,a,i)=>s+(a===activeLesson.questions[i].answer?1:0),0)/activeLesson.questions.length*100)}<small>%</small></div><p>Your progress has been saved on this device.</p><button className="primary" onClick={()=>setPage('home')}>Back to dashboard</button></div>}</section>}
      {page==='teacher' && <Teacher records={records} onRefresh={refresh} onSync={syncProgress}/>}
      <footer>© 2026 NovaLearn · Learning for every learner, everywhere.</footer>
    </main>
  </div>;
}
function Stat({label,value,note,icon}) { return <div className="stat-card"><div className="stat-top"><span>{label}</span><div>{icon}</div></div><strong>{value}</strong><small>{note}</small></div>; }
function Teacher({records,onRefresh,onSync}) {
  const [all,setAll]=useState([]);
  useEffect(()=>{onRefresh();},[]);
  useEffect(()=>{setAll(records);},[records]);
  const avg=all.length?Math.round(all.reduce((s,r)=>s+r.score,0)/all.length):0;
  const students=[...new Set(all.map(r=>r.studentName))];
  const topics={}; all.forEach(r=>(r.weakTopics||[]).forEach(t=>topics[t]=(topics[t]||0)+1));
  const weak=Object.entries(topics).sort((a,b)=>b[1]-a[1]);
  return <section className="teacher-view"><div className="teacher-intro"><div><p className="eyebrow">CLASSROOM OVERVIEW</p><h1>Learning progress</h1><p className="muted">A quick view of student practice and topics that need attention.</p></div><div className="teacher-actions"><button className="secondary" onClick={onRefresh}><RefreshCw size={16}/> Refresh</button><button className="primary" onClick={onSync}>Sync device data</button></div></div><div className="stats-grid"><Stat label="Students" value={students.length} note="Learners with synced attempts" icon={<GraduationCap/>}/><Stat label="Quiz attempts" value={all.length} note="Total completed quizzes" icon={<CheckCircle2/>}/><Stat label="Class average" value={`${avg}%`} note="Average quiz score" icon={<BarChart3/>}/></div><div className="teacher-columns"><div className="table-card"><div className="card-heading"><h3>Recent student results</h3><span className="pill">{all.length} records</span></div>{all.length?<div className="table-wrap"><table><thead><tr><th>Student</th><th>Lesson</th><th>Score</th><th>Date</th></tr></thead><tbody>{[...all].sort((a,b)=>new Date(b.completedAt)-new Date(a.completedAt)).map(r=><tr key={r.id}><td><b>{r.studentName}</b><small>Class {r.grade}</small></td><td>{r.lessonTitle}</td><td><span className={r.score>=70?'score-pill good':'score-pill'}>{r.score}%</span></td><td>{new Date(r.completedAt).toLocaleDateString()}</td></tr>)}</tbody></table></div>:<div className="empty-state"><BookOpen size={30}/><b>No student results yet</b><p>Complete a quiz and sync progress to see it here.</p></div>}</div><div className="table-card weak-card"><div className="card-heading"><h3>Topics to revisit</h3></div>{weak.length?weak.map(([topic,count])=><div className="weak-row" key={topic}><div><b>{topic}</b><small>{count} incorrect response group(s)</small></div><span>{count}</span></div>):<div className="empty-state"><Sparkles size={28}/><b>No weak topics yet</b><p>Quiz mistakes will appear here.</p></div>}</div></div></section>;
}
