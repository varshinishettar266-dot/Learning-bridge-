export const lessons = [
  {
    id: 'fractions', subject: 'Mathematics', title: 'Understanding Fractions',
    titleKn: 'ಭಿನ್ನರಾಶಿಗಳನ್ನು ತಿಳಿಯಿರಿ', className: 'Class 6', minutes: 8,
    body: 'A fraction represents a part of a whole. It has a numerator (top number) and a denominator (bottom number). For example, 1/2 means one out of two equal parts.',
    bodyKn: 'ಭಿನ್ನರಾಶಿ ಎಂದರೆ ಒಂದು ಪೂರ್ಣ ವಸ್ತುವಿನ ಒಂದು ಭಾಗ. ಇದರಲ್ಲಿ ಅಂಶ (ಮೇಲಿನ ಸಂಖ್ಯೆ) ಮತ್ತು ಛೇದ (ಕೆಳಗಿನ ಸಂಖ್ಯೆ) ಇರುತ್ತವೆ. ಉದಾಹರಣೆಗೆ, 1/2 ಎಂದರೆ ಎರಡು ಸಮಾನ ಭಾಗಗಳಲ್ಲಿ ಒಂದು ಭಾಗ.',
    questions: [
      { q: 'In 1/2, what is the numerator?', qKn: '1/2 ರಲ್ಲಿ ಅಂಶ ಯಾವುದು?', options: ['1','2','3','0'], answer: 0, topic: 'Numerator' },
      { q: 'Which fraction means one out of four equal parts?', qKn: 'ನಾಲ್ಕು ಸಮಾನ ಭಾಗಗಳಲ್ಲಿ ಒಂದು ಭಾಗವನ್ನು ಯಾವ ಭಿನ್ನರಾಶಿ ಸೂಚಿಸುತ್ತದೆ?', options: ['1/2','1/3','1/4','4/1'], answer: 2, topic: 'Basic fractions' },
      { q: 'What is 1/2 + 1/2?', qKn: '1/2 + 1/2 ಎಷ್ಟು?', options: ['1/4','1','2','1/2'], answer: 1, topic: 'Adding fractions' },
      { q: 'Which is greater?', qKn: 'ಯಾವುದು ದೊಡ್ಡದು?', options: ['1/4','3/4','They are equal','Cannot say'], answer: 1, topic: 'Comparing fractions' }
    ]
  },
  {
    id: 'addition', subject: 'Mathematics', title: 'Addition Basics',
    titleKn: 'ಸಂಕಲನದ ಮೂಲಭೂತ ಅಂಶಗಳು', className: 'Class 6', minutes: 6,
    body: 'Addition combines two or more numbers to find their total. The plus sign (+) is used for addition. Example: 12 + 8 = 20.',
    bodyKn: 'ಎರಡು ಅಥವಾ ಹೆಚ್ಚಿನ ಸಂಖ್ಯೆಗಳನ್ನು ಸೇರಿಸಿ ಒಟ್ಟು ಮೊತ್ತ ಕಂಡುಹಿಡಿಯುವುದನ್ನು ಸಂಕಲನ ಎನ್ನುತ್ತಾರೆ. ಸಂಕಲನಕ್ಕೆ (+) ಚಿಹ್ನೆ ಬಳಸಲಾಗುತ್ತದೆ. ಉದಾಹರಣೆ: 12 + 8 = 20.',
    questions: [
      { q: 'What is 12 + 8?', qKn: '12 + 8 ಎಷ್ಟು?', options: ['18','20','22','16'], answer: 1, topic: 'Addition' },
      { q: 'What is 15 + 5?', qKn: '15 + 5 ಎಷ್ಟು?', options: ['10','15','20','25'], answer: 2, topic: 'Addition' },
      { q: 'What is 9 + 7?', qKn: '9 + 7 ಎಷ್ಟು?', options: ['14','15','16','17'], answer: 2, topic: 'Addition' }
    ]
  }
];
