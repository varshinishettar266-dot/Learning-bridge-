# NovaLearn – Offline-first adaptive learning MVP

A beginner-friendly hackathon prototype with:
- React + Vite student and teacher screens
- IndexedDB local progress storage (offline)
- Service Worker / installable PWA
- Node.js + Express API
- JSON-file backend persistence for a zero-configuration demo
- Optional Firebase Firestore sync integration

## Requirements
Install Node.js LTS (20 or newer) and VS Code.

## Run it
1. Extract the ZIP.
2. Open the `NovaLearn` folder in VS Code.
3. Open Terminal > New Terminal.
4. Run:
   ```bash
   npm run install:all
   ```
5. Start both frontend and backend:
   ```bash
   npm run dev
   ```
6. Open http://localhost:5173

Backend health check: http://localhost:5000/api/health

## First demo
1. Open the website and enter a student name, class and language.
2. Choose a lesson and answer its quiz.
3. Progress is saved locally in IndexedDB, even if you disconnect the internet after the app has loaded.
4. Click **Sync progress** when online.
5. Open the **Teacher dashboard** to view synced students and topic performance.

## Firebase (optional cloud database)
The app works without Firebase using the Express server's local JSON database (`server/data/progress.json`).
To enable Firestore:
1. Create a Firebase project at https://console.firebase.google.com
2. Add a Web App and copy its Firebase config.
3. Copy `client/.env.example` to `client/.env` and fill in the values.
4. In Firebase Console, enable Firestore Database.
5. Publish the starter rules in `firebase/firestore.rules`.
6. Restart the frontend (`npm run client`).

When Firebase is configured, the client writes synced progress to Firestore collection `studentProgress`. The Express API remains the demo sync/report API.

## Project folders
- `client/` – React frontend, PWA, IndexedDB and Firebase client integration
- `server/` – Express backend and local JSON fallback database
- `firebase/` – starter Firestore security rules

## Important MVP notes
- This is a hackathon demonstration, not a production student information system.
- Do not collect Aadhaar numbers, passwords, or sensitive personal data.
- Firebase starter rules are intentionally simple for a demo. Before public deployment, add Firebase Authentication and restrict each student's records to their own account; give teachers role-based access.
- The sample lessons and quiz questions are demo content. Ask teachers to review educational accuracy before school use.
- Bhashini API integration requires approved credentials. This MVP uses Kannada/English text and browser speech synthesis where supported.
