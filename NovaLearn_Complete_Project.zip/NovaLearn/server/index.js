import express from 'express';
import cors from 'cors';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const app = express();
const PORT = process.env.PORT || 5000;
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const dataDir = path.join(__dirname, 'data');
const dataFile = path.join(dataDir, 'progress.json');
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });
if (!fs.existsSync(dataFile)) fs.writeFileSync(dataFile, '[]');

app.use(cors());
app.use(express.json({ limit: '1mb' }));

function readRecords() {
  try { return JSON.parse(fs.readFileSync(dataFile, 'utf8')); }
  catch { return []; }
}
function writeRecords(records) {
  fs.writeFileSync(dataFile, JSON.stringify(records, null, 2));
}

app.get('/api/health', (_req, res) => res.json({ status: 'ok', app: 'NovaLearn API' }));
app.get('/api/progress', (_req, res) => res.json(readRecords()));

app.post('/api/sync', (req, res) => {
  const incoming = req.body?.records;
  if (!Array.isArray(incoming)) return res.status(400).json({ message: 'records must be an array' });
  const existing = readRecords();
  const byId = new Map(existing.map(record => [record.id, record]));
  for (const record of incoming) {
    if (!record || !record.id || !record.studentName || typeof record.score !== 'number') continue;
    byId.set(record.id, { ...record, synced: true });
  }
  const saved = [...byId.values()];
  writeRecords(saved);
  res.json({ message: 'Progress synchronized', count: incoming.length, total: saved.length });
});

app.get('/api/students', (_req, res) => {
  const records = readRecords();
  const names = [...new Set(records.map(r => r.studentName))];
  res.json(names.map(name => ({ name, attempts: records.filter(r => r.studentName === name).length })));
});

app.listen(PORT, () => console.log(`NovaLearn API running at http://localhost:${PORT}`));
